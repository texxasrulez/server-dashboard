#!/bin/bash
set -euo pipefail

# Conservative, explicit PATH for cron/systemd/PHP
PATH="/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
export PATH

# Safer default permissions for any created files/dirs
umask 027

# Dashboard state (backup_actions.json / backup_status.json)
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DEFAULT_WEB_ROOT="/home/gene/web/genesworld.net/public_html/web-admin"
if [ -n "${WEB_ADMIN_ROOT:-}" ]; then
  WEB_ADMIN_ROOT="$WEB_ADMIN_ROOT"
elif [ -d "$DEFAULT_WEB_ROOT" ]; then
  WEB_ADMIN_ROOT="$DEFAULT_WEB_ROOT"
else
  WEB_ADMIN_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
fi
STATE_DIR="${STATE_DIR:-$WEB_ADMIN_ROOT/state}"
ACTIONS_JSON="${STATE_DIR}/backup_actions.json"
STATUS_JSON="${STATE_DIR}/backup_status.json"
mkdir -p "$STATE_DIR" 2>/dev/null || true
STATE_OWNER="${STATE_OWNER:-}"
if [ -z "$STATE_OWNER" ] && [ -f "$STATE_DIR/.owner" ]; then
  STATE_OWNER="$(tr -d " \r\n" < "$STATE_DIR/.owner" 2>/dev/null || true)"
fi
if [ -z "$STATE_OWNER" ]; then
  STATE_OWNER="webuser:webuser"
fi

log_action_json() {
  local action="$1"
  local ok="$2"
  local message="${3:-}"
  local log_path="${4:-}"
  if ! command -v python3 >/dev/null 2>&1; then
    return 0
  fi
  ACTION_NAME="$action" ACTION_OK="$ok" ACTION_MESSAGE="$message" ACTION_LOG_PATH="$log_path" ACTION_SCRIPT="$0" ACTION_STATE_FILE="$ACTIONS_JSON" \
  python3 - <<'PY' || true
import os, json, tempfile, datetime
path = os.environ.get("ACTION_STATE_FILE")
if not path:
    raise SystemExit(0)
entry = {
    "ts": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "action": os.environ.get("ACTION_NAME"),
    "ok": os.environ.get("ACTION_OK","true").lower() not in ("0","false","no"),
    "message": os.environ.get("ACTION_MESSAGE") or None,
    "job_id": None,
    "script": os.environ.get("ACTION_SCRIPT"),
    "log": os.environ.get("ACTION_LOG_PATH") or None,
    "meta": None,
}
entries = []
try:
    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)
        if isinstance(data, list):
            entries = data
except FileNotFoundError:
    pass
except Exception:
    entries = []
entries.append(entry)
if len(entries) > 50:
    entries = entries[-50:]
os.makedirs(os.path.dirname(path), exist_ok=True)
fd, tmp = tempfile.mkstemp(prefix=os.path.basename(path) + ".tmp.", dir=os.path.dirname(path))
with os.fdopen(fd, "w", encoding="utf-8") as f:
    json.dump(entries, f, indent=2)
os.replace(tmp, path)
PY
  if [ -f "$ACTIONS_JSON" ]; then
    chown "$STATE_OWNER" "$ACTIONS_JSON" 2>/dev/null || true
    chmod 644 "$ACTIONS_JSON" 2>/dev/null || true
  fi
}

refresh_backup_status() {
  local script="${SCRIPT_DIR}/backup_health_check.sh"
  if [ -x "$script" ] && [ "$script" != "$0" ]; then
    "$script" >/dev/null 2>&1 || true
  fi
}

ACTION_NAME="micro_backup"
ACTION_MESSAGE="Completed micro backup"
finish_action() {
  local code=$?
  local ok=true
  local msg="$ACTION_MESSAGE"
  if [ "$code" -ne 0 ]; then
    ok=false
    msg="Failed with exit ${code}"
  fi
  log_action_json "$ACTION_NAME" "$ok" "$msg" "$LOG_FILE"
  if [ "$ok" = true ]; then
    refresh_backup_status
  fi
}
trap finish_action EXIT

CONFIG_FILE="${WEB_ADMIN_ROOT}/config/local.json"
BACKUP_DEBUG="${BACKUP_DEBUG:-}"
if [ -z "${BACKUP_ROOT:-}" ] && command -v jq >/dev/null 2>&1 && [ -f "$CONFIG_FILE" ]; then
  cfg_root="$(jq -r '.backups.fs_root // empty' "$CONFIG_FILE" 2>/dev/null || true)"
  if [ -n "$cfg_root" ]; then
    BACKUP_ROOT="$cfg_root"
  fi
fi
if [ -z "${BACKUP_EXCLUDES:-}" ] && command -v jq >/dev/null 2>&1 && [ -f "$CONFIG_FILE" ]; then
  cfg_excludes="$(jq -r '.backups.exclude_dirs // empty' "$CONFIG_FILE" 2>/dev/null || true)"
  if [ -n "$cfg_excludes" ]; then
    BACKUP_EXCLUDES="$cfg_excludes"
    export BACKUP_EXCLUDES
  fi
fi
if [ -z "$BACKUP_DEBUG" ] && command -v jq >/dev/null 2>&1 && [ -f "$CONFIG_FILE" ]; then
  BACKUP_DEBUG="$(jq -r '.backups.debug // empty' "$CONFIG_FILE" 2>/dev/null || true)"
fi

EXCLUDES_RAW="${BACKUP_EXCLUDES:-}"
EXCLUDES=()
if [[ -n "$EXCLUDES_RAW" ]]; then
  EXCLUDES_RAW="$(echo "$EXCLUDES_RAW" | tr ',\n' '  ')"
  read -r -a EXCLUDES <<< "$EXCLUDES_RAW"
fi

is_excluded() {
  local path="$1"
  local p="${path%/}"
  local ex
  for ex in "${EXCLUDES[@]}"; do
    ex="${ex%/}"
    [ -z "$ex" ] && continue
    if [[ "$p" == $ex || "$p" == $ex/* ]]; then
      return 0
    fi
  done
  return 1
}

BACKUP_ROOT="${BACKUP_ROOT:-/mnt/backupz}"
BACKUP="${BACKUP_ROOT%/}/micro"
STAMP="$(date +%Y%m%d-%H%M)"
TARGET="$BACKUP/$STAMP"

LOG_FILE="/var/log/micro-backup.log"
HOSTNAME="$(hostname -f 2>/dev/null || hostname)"
NOW_HUMAN="$(date "+%Y-%m-%d %H:%M:%S")"

# Ensure base backup and log dirs exist
mkdir -p "$BACKUP"
mkdir -p "$(dirname "$LOG_FILE")"

if [[ "$BACKUP_DEBUG" == "1" || "$BACKUP_DEBUG" == "true" ]]; then
  echo "[DEBUG] BACKUP_ROOT=${BACKUP_ROOT}" >> "$LOG_FILE"
  echo "[DEBUG] BACKUP_EXCLUDES=${BACKUP_EXCLUDES:-}" >> "$LOG_FILE"
fi

mkdir -p "$TARGET"

# Database dumps
/usr/bin/mariadb-dump --all-databases > "$TARGET/all-databases.sql"

# Critical configs
if is_excluded "/etc"; then
  echo "[INFO] Skipping excluded path /etc" >> "$LOG_FILE"
else
  cp -a /etc "$TARGET/etc"
fi
if is_excluded "/usr/local"; then
  echo "[INFO] Skipping excluded path /usr/local" >> "$LOG_FILE"
else
  cp -a /usr/local "$TARGET/usr-local"
fi
if is_excluded "/var/vmail"; then
  echo "[INFO] Skipping excluded path /var/vmail" >> "$LOG_FILE"
else
  cp -a /var/vmail "$TARGET/var-vmail" 2>/dev/null || true
fi
if is_excluded "/var/lib/nginx"; then
  echo "[INFO] Skipping excluded path /var/lib/nginx" >> "$LOG_FILE"
else
  cp -a /var/lib/nginx "$TARGET/var-lib-nginx" 2>/dev/null || true
fi
if is_excluded "/home/gene/web"; then
  echo "[INFO] Skipping excluded path /home/gene/web" >> "$LOG_FILE"
else
  cp -a /home/gene/web "$TARGET/web" 2>/dev/null || true
fi

chown -R gene:gene "$TARGET"

# Compute size for quick-at-a-glance log info (best-effort)
SIZE_HUMAN="$(du -sh "$TARGET" 2>/dev/null | awk '{print $1}')"

# Append a simple summary line to the same log PHP tails/rotates
{
  printf '%s HOST=%s ACTION=micro_backup STATUS=OK TARGET=%s SIZE=%s\n' \
    "$NOW_HUMAN" "$HOSTNAME" "$TARGET" "${SIZE_HUMAN:-n/a}"
} >> "$LOG_FILE"

exit 0
