// assets/js/pages/config.cron.js — disabled
(function(){ 'use strict';
  // Cron module intentionally disabled by request. This stub ensures no listeners/dom writes.
})();