# Sweep Report

**Date:** 2025-08-11

## Moved to _legacy/
- api/metrics.php.bak
- api/service_delete.php.bak
- api/service_probe.php.bak
- api/service_upsert.php.bak
- api/services.php.bak
- api/services_bulk_save.php.bak
- api/services_list.php.bak
- assets/js/app.js.bak
- assets/js/logs.js.bak
- assets/js/pages/index.js.bak
- assets/js/pages/index_services_patch.js.bak
- assets/js/pages/services.js.bak
- _legacy/bak/api/metrics.php.bak
- _legacy/bak/api/service_delete.php.bak
- _legacy/bak/api/service_probe.php.bak
- _legacy/bak/api/service_upsert.php.bak
- _legacy/bak/api/services.php.bak
- _legacy/bak/api/services_bulk_save.php.bak
- _legacy/bak/api/services_list.php.bak
- _legacy/bak/assets/js/app.js.bak
- _legacy/bak/assets/js/logs.js.bak
- _legacy/bak/assets/js/pages/index.js.bak
- _legacy/bak/assets/js/pages/index_services_patch.js.bak
- _legacy/bak/assets/js/pages/services.js.bak
- assets/js/header_status.js
- assets/js/index_autoprobe_bind.js
- assets/js/index_process_bars.js
- assets/js/index_refresh.js

## Removed
_(none)_

## Edited / Created
- includes/foot.php
- index.php
