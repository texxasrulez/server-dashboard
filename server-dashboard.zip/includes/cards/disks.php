<div class="card">
  <div class="section-title">Hard Drive Status</div>
  <div id="diskGrid" class="disk-grid"></div>
</div>
