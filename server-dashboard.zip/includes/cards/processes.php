<div class="card">
  <div class="section-title">Server Processes</div>
  <div id="procGrid" class="proc-grid"></div>
</div>
