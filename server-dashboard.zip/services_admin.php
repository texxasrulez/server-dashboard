<?php
header('Location: services.php', true, 301);
exit;
